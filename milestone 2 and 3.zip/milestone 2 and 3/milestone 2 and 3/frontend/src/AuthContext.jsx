import { createContext, useState, useEffect } from "react";
import { authAPI } from "./api/userAPI";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Check if user is logged in by trying to fetch current user
  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Try to get current user from backend using JWT cookie
        const userData = await authAPI.getCurrentUser();
        if (userData) {
          setUser(userData);
        }
      } catch (error) {
        // User is not logged in or token is invalid
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const register = async (username, password, age, parentPhone) => {
    try {
      await authAPI.register(username, password, age, parentPhone);
      // Redirect to login page
      window.location.href = "/login";
    } catch (error) {
      throw error;
    }
  };

  const login = async (username, password) => {
    try {
      const userData = await authAPI.login(username, password);
      setUser(userData);
      // Redirect to home
      window.location.href = "/";
    } catch (error) {
      throw error;
    }
  };

  const logout = async () => {
    try {
      await authAPI.logout();
      setUser(null);
    } catch (error) {
      setUser(null);
    } finally {
      window.location.href = "/";
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, register, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
