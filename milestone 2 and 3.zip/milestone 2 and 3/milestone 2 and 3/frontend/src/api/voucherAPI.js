const API_BASE = "http://localhost:3000/api";

export const voucherAPI = {
  getVouchers: async () => {
    const response = await fetch(`${API_BASE}/vouchers`, {
      method: "GET",
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to fetch vouchers");

    return await response.json();
  },

  createVoucher: async (voucherData) => {
    const response = await fetch(`${API_BASE}/vouchers`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(voucherData),
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to create voucher");

    return await response.json();
  },

  updateVoucher: async (id, voucherData) => {
    const response = await fetch(`${API_BASE}/vouchers/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(voucherData),
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to update voucher");

    return await response.json();
  },

  deleteVoucher: async (id) => {
    const response = await fetch(`${API_BASE}/vouchers/${id}`, {
      method: "DELETE",
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to delete voucher");

    return await response.json();
  },
};
