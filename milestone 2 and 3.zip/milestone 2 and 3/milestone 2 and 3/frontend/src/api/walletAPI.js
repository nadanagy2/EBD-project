const API_BASE = "http://localhost:3000/api";

export const walletAPI = {
  getWallets: async () => {
    const response = await fetch(`${API_BASE}/wallets`, {
      method: "GET",
      credentials: "include",
    });

    if (!response.ok) {
      throw new Error("Failed to fetch wallets");
    }

    return await response.json();
  },

  getWalletsByChild: async (childId) => {
    const response = await fetch(`${API_BASE}/wallets?childId=${childId}`, {
      method: "GET",
      credentials: "include",
    });

    if (!response.ok) {
      throw new Error("Failed to fetch wallet");
    }

    return await response.json();
  },

  createWallet: async (walletData) => {
    const response = await fetch(`${API_BASE}/wallets`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(walletData),
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to create wallet");

    return await response.json();
  },

  updateWallet: async (id, walletData) => {
    const response = await fetch(`${API_BASE}/wallets/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(walletData),
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to update wallet");

    return await response.json();
  },

  deleteWallet: async (id) => {
    const response = await fetch(`${API_BASE}/wallets/${id}`, {
      method: "DELETE",
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to delete wallet");

    return await response.json();
  },
};
