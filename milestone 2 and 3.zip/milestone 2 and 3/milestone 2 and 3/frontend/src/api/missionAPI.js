const API_BASE = "http://localhost:3000/api";

export const missionAPI = {
  getMissions: async () => {
    const response = await fetch(`${API_BASE}/missions`, {
      method: "GET",
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to fetch missions");

    return await response.json();
  },

  getMissionsByChild: async (childId) => {
    const response = await fetch(`${API_BASE}/missions?childId=${childId}`, {
      method: "GET",
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to fetch missions");

    return await response.json();
  },

  createMission: async (missionData) => {
    const response = await fetch(`${API_BASE}/missions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(missionData),
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to create mission");

    return await response.json();
  },

  updateMission: async (id, missionData) => {
    const response = await fetch(`${API_BASE}/missions/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(missionData),
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to update mission");

    return await response.json();
  },

  deleteMission: async (id) => {
    const response = await fetch(`${API_BASE}/missions/${id}`, {
      method: "DELETE",
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to delete mission");

    return await response.json();
  },
};
