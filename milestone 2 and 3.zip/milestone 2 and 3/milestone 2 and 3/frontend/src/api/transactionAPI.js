const API_BASE = "http://localhost:3000/api";

export const transactionAPI = {
  getTransactions: async () => {
    const response = await fetch(`${API_BASE}/transactions`, {
      method: "GET",
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to fetch transactions");

    return await response.json();
  },

  getTransactionsByChild: async (childId) => {
    const response = await fetch(`${API_BASE}/transactions?childId=${childId}`, {
      method: "GET",
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to fetch transactions");

    return await response.json();
  },

  createTransaction: async (transactionData) => {
    const response = await fetch(`${API_BASE}/transactions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(transactionData),
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to create transaction");

    return await response.json();
  },

  updateTransaction: async (id, transactionData) => {
    const response = await fetch(`${API_BASE}/transactions/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(transactionData),
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to update transaction");

    return await response.json();
  },

  deleteTransaction: async (id) => {
    const response = await fetch(`${API_BASE}/transactions/${id}`, {
      method: "DELETE",
      credentials: "include",
    });

    if (!response.ok) throw new Error("Failed to delete transaction");

    return await response.json();
  },
};
