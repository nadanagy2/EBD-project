const API_BASE = "http://localhost:3000/api";

export const authAPI = {

  // ===== Register User =====
  register: async (username, password, age, parentPhone) => {
    // Send user data to backend
    const response = await fetch(`${API_BASE}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ 
        username, 
        password, 
        age: Number(age),
        Parent_phone: Number(parentPhone)
      }),
      credentials: "include",
    });

    // Handle registration error
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || "Registration failed");
    }

    // Return success response
    return await response.json();
  },

  // ===== User Login =====
  login: async (username, password) => {
    // Send login credentials
    const response = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
      credentials: "include",
    });

    // Handle authentication error
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || "Login failed");
    }

    // Return authenticated user data
    return await response.json();
  },

  // ===== User Logout =====
  logout: async () => {
    // End user session
    const response = await fetch(`${API_BASE}/auth/logout`, {
      method: "GET",
      credentials: "include",
    });

    // Handle logout error
    if (!response.ok) {
      throw new Error("Logout failed");
    }

    return await response.json();
  },

  // ===== Get Current User =====
  getCurrentUser: async () => {
    try {
      // Check if user is authenticated
      const response = await fetch(`${API_BASE}/auth/me`, {
        method: "GET",
        credentials: "include",
      });

      // If not authenticated, return null
      if (!response.ok) {
        return null;
      }

      // Return logged-in user data
      return await response.json();
    } catch (error) {
      // Handle network or server error
      return null;
    }
  },
};
