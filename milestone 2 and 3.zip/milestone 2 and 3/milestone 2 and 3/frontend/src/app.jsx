import { useEffect, useState, useContext } from "react";
import { Routes, Route } from "react-router-dom";
import { AuthContext } from "./context/AuthContext";

import Header from "./components/HeaderTitle/Header.jsx";

// CORRECTED PATHS: These now match your nested folder structure exactly
import WelcomePage from "./pages/WelcomePage/welcomepage.jsx"; 
import LoginPage from "./pages/LoginPage/LoginPage.jsx";
import RegisterPage from "./pages/RegisterPage/Register.jsx";
import WalletPage from "./pages/WalletPage/Wallet.jsx";
import MissionsPage from "./pages/MissionsPage/Mission.jsx";
import VoucherPage from "./pages/VoucherPage/voucher.jsx";
import TransactionsHistoryPage from "./pages/TransactionsHistoryPage/TransactionHistory.jsx";
import GameLoading from "./pages/GameLoading/GameLoading.jsx";
import GamesPage from "./pages/GamesPage/GamesPage.jsx";
import GamePlay from "./pages/GamePlay/GamePlay.jsx";

import { walletAPI } from "./api/walletAPI";
import { missionAPI } from "./api/missionAPI";
import { voucherAPI } from "./api/voucherAPI";
import { transactionAPI } from "./api/transactionAPI";

import "./app.css";

function App() {
  const { user, loading: authLoading } = useContext(AuthContext);

  const [wallet, setWallet] = useState(null);
  const [missions, setMissions] = useState([]);
  const [vouchers, setVouchers] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      if (!user) {
        setLoading(false);
        return;
      }

      try {
        const [
          walletRes,
          missionsRes,
          vouchersRes,
          transactionsRes,
        ] = await Promise.all([
          walletAPI.getWallets(),
          missionAPI.getMissions(),
          voucherAPI.getVouchers(),
          transactionAPI.getTransactions(),
        ]);

        const userWallet = walletRes.find(
          (w) => w.childId?._id === user._id
        );

        setWallet(userWallet || null);
        setMissions(missionsRes);
        setVouchers(vouchersRes);
        setTransactions(transactionsRes);
      } catch (error) {
        console.error("Failed to load data:", error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [user]);

  if (authLoading || loading) {
    return (
      <div className="App">
        <Header />
        <div className="loading-state">
           <p>Loading application data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="App">
      <Header />

      <div className="main-container">
        <Routes>
          <Route
            path="/"
            element={user ? <WelcomePage /> : <LoginPage />}
          />

          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />

          <Route
            path="/wallets"
            element={<WalletPage wallet={wallet} />}
          />

          <Route
            path="/missions"
            element={<MissionsPage missions={missions} />}
          />

          <Route
            path="/vouchers"
            element={<VoucherPage vouchers={vouchers} />}
          />

          <Route
            path="/welcome"
            element={<WelcomePage />}
          />

          <Route
            path="/transactions"
            element={
              <TransactionsHistoryPage transactions={transactions} />
            }
          />

          <Route path="/game" element={<GameLoading />} />

          <Route path="/games" element={<GamesPage />} />
          <Route path="/game/:id" element={<GamePlay />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;