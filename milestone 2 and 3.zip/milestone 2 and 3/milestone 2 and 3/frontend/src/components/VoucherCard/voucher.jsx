import "./voucher.css";

const VoucherCard = ({ voucher, onBuy }) => {
  return (
    <div className="voucher-card">
      <h2 className="voucher-title">{voucher.title}</h2>
      <p className="voucher-merchant"><strong>Merchant:</strong> {voucher.merchant}</p>
      <p className="voucher-price"><strong>Price:</strong> {voucher.price} EGP</p>
      <button className="voucher-btn" onClick={() => onBuy(voucher)}>
        Buy Now
      </button>
    </div>
  );
};

export default VoucherCard;
