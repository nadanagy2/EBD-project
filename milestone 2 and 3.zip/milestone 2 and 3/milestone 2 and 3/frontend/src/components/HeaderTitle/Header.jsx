// src/components/Header/Header.jsx
import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../../context/AuthContext";
import "./Header.css";

const Header = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await logout();
      navigate("/login");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <header className="app-header" role="banner">
      <div className="header-inner">
        <div className="header-left">
          <div className="header-brand">
            <img src="/logo.png" alt="FinQuest Kids" className="app-logo" />
            <h1>FinQuest Kids</h1>
          </div>

          {user && (
            <div className="logout-wrap">
              <button onClick={handleLogout} className="logout-btn">
                Logout
              </button>
            </div>
          )}
        </div>

        <div className="header-center" aria-hidden="true" />

        <div className="header-right" />
      </div>
    </header>
  );
};

export default Header;
