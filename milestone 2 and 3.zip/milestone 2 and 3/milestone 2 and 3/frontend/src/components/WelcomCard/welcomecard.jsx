
import "./welcomecard.css";

const WelcomeCard = ({ username }) => {
  return (
    <div className="welcome-card">
      <h2>Welcome, {username}!</h2>
      <p>Ready to explore FinQuest Kids?</p>
    </div>
  );
};

export default WelcomeCard;
