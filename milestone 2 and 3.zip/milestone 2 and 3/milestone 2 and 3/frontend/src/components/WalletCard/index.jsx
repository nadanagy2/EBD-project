import "./style.css";

const WalletCard = ({ wallet }) => {
  const { spendJar, saveJar, donateJar, IsActive } = wallet;

  return (
    <div className="wallet-card">
      <h3>My Wallet</h3>
      <p className="wallet-item">Spend Jar: {spendJar} EGP</p>
      <p className="wallet-item">Save Jar: {saveJar} EGP</p>
      <p className="wallet-item">Donate Jar: {donateJar} EGP</p>
      <p className="wallet-item">Active: {IsActive ? "Yes" : "No"}</p>
    </div>
  );
};

export default WalletCard;
