import React from "react";
import { useNavigate } from "react-router-dom";
import "./GameCard.css";

export default function GameCard({ id, title, reward, description }) {
  const navigate = useNavigate();

  return (
    <div className="game-card card">
      <div>
        <h3 className="game-title">{title}</h3>
        <p className="game-desc">{description}</p>
      </div>

      <div className="game-footer">
        <span className="reward">{reward} EGP</span>
        <button
          className="start-game"
          onClick={() => navigate(`/game/${id}`, { state: { id, title, reward, description } })}
        >
          Start Game
        </button>
      </div>
    </div>
  );
}
