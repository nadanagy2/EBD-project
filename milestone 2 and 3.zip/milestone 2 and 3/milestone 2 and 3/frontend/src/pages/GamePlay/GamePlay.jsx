import React, { useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import "./gamePlay.css";

export default function GamePlay() {
  const { state } = useLocation();
  const { id } = useParams();
  const navigate = useNavigate();

  // fallback in case state isn't provided
  const game = state || { id, title: `Game ${id}`, reward: 0, description: "Play and win!" };

  const [playing, setPlaying] = useState(false);
  const [finished, setFinished] = useState(false);

  function startGame() {
    setPlaying(true);
    // simulate simple small game duration
    setTimeout(() => {
      setPlaying(false);
      setFinished(true);
    }, 1400);
  }

  return (
    <div className="page-container gameplay-page">
      <div className="wallets-container">
        <h1>{game.title}</h1>

        <div className="game-area">
          {!playing && !finished && (
            <>
              <p className="game-instr">{game.description}</p>
              <p className="game-reward">Reward: <strong>{game.reward} EGP</strong></p>
              <button className="play-btn" onClick={startGame}>Start</button>
            </>
          )}

          {playing && <div className="playing">Playing... <div className="spinner" aria-hidden/></div>}

          {finished && (
            <div className="finished">
              <h3>Congratulations!</h3>
              <p>You earned <strong>{game.reward} EGP</strong>.</p>
              <div className="actions">
                <button onClick={() => navigate("/games")}>Back to Games</button>
                <button onClick={() => navigate("/")}>Return Home</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
