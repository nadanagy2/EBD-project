import { useState, useEffect, useContext } from "react";
import { AuthContext } from "../../context/AuthContext";
import WalletCard from "../../components/WalletCard";
import "./wallet.css";

const WalletPage = () => {
  const [wallet, setWallet] = useState(null);
  const { user } = useContext(AuthContext);

  useEffect(() => {
    if (user) {
      fetch(`http://localhost:3000/api/wallets?childId=${user.id}`, {
        credentials: "include",
      })
        .then((res) => res.json())
        .then((data) => setWallet(data[0]))
        .catch((err) => console.error(err));
    }
  }, [user]);

  if (!wallet)
    return (
      <div className="page-container">
        <div className="wallets-container">
          <p>No wallet found.</p>
        </div>
      </div>
    );

  return (
    <div className="page-container">
      <div className="wallets-container">
        <h1>Your Wallet</h1>
        <WalletCard wallet={wallet} />
      </div>
    </div>
  );
};

export default WalletPage;
