import { useState, useEffect } from "react";
import VoucherCard from "../../components/VoucherCard/voucher.jsx";
import "./voucher.css";

const VoucherPage = () => {
  const [vouchers, setVouchers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch("http://localhost:3000/api/vouchers", {
      credentials: "include",
    })
      .then(res => {
        console.log("📡 Voucher API Status:", res.status);
        if (!res.ok) {
          throw new Error(`API returned status ${res.status}`);
        }
        return res.json();
      })
      .then(data => {
        console.log("✅ Vouchers received:", data);
        setVouchers(data);
        setError(null);
      })
      .catch(err => {
        console.error("❌ Error fetching vouchers:", err);
        setError(err.message);
      })
      .finally(() => setLoading(false));
  }, []);

  const handleBuyNow = (voucher) => {
    alert(`You clicked Buy Now for: ${voucher.title}`);
  };

  return (
    <div className="page-container">
      <div className="voucher-page-container">
        <h1>Available Vouchers</h1>
        
        {loading && <p>Loading vouchers...</p>}
        {error && <p style={{ color: "red" }}>❌ Error: {error}</p>}
        
        <div className="voucher-grid">
          {!loading && !error && vouchers.length === 0 ? (
            <p>No vouchers available.</p>
          ) : (
            vouchers.map(v => (
              <VoucherCard key={v._id} voucher={v} onBuy={handleBuyNow} />
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default VoucherPage;
