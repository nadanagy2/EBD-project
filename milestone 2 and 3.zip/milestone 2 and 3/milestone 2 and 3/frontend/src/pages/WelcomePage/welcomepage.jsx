import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
// Fixed: Path goes up two levels to reach src, then into components
import WelcomeCard from "../../components/WelcomCard/welcomecard.jsx";
import "./welcome.css";

const WelcomePage = () => {
  const [child, setChild] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchChild = async () => {
      try {
        const res = await fetch("http://localhost:3000/api/auth/me", {
          credentials: "include", // Required to send cookies to the backend
        });
        
        if (!res.ok) throw new Error("Failed to fetch user");
        
        const data = await res.json();
        setChild(data);
      } catch (err) {
        console.error("Auth error:", err);
        navigate("/login"); // Redirect if not authenticated
      }
    };
    fetchChild();
  }, [navigate]);

  if (!child) return <div className="page-container"><div className="loading">Loading...</div></div>;

  return (
    <div className="page-container welcome-page">
      <div className="welcome-container">
        <WelcomeCard username={child.username} />

        <div className="button-grid">
          <button onClick={() => navigate("/wallets")}>Wallet</button>
          <button onClick={() => navigate("/vouchers")}>Voucher</button>
          <button onClick={() => navigate("/missions")}>Missions</button>
          <button onClick={() => navigate("/transactions")}>Transactions</button>
        </div>

        <div className="play-section">
          <h2>Are you ready to play?</h2>
          <button className="play-now" onClick={() => navigate("/games")}>Play now</button>
        </div>
      </div>
    </div>
  );
};

export default WelcomePage;