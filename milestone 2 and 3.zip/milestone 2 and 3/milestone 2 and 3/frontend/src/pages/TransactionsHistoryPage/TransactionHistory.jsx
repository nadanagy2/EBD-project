import { useEffect, useState } from "react";
// Fixed: Path goes up two levels to reach src
import TransactionCard from "../../components/TransactionCard/Transaction.jsx";

const TransactionsHistoryPage = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        console.log("📡 Fetching transactions...");
        const res = await fetch("http://localhost:3000/api/transactions", {
          credentials: "include",
        });
        
        console.log("📡 Transaction API Status:", res.status);
        
        if (!res.ok) {
          throw new Error(`API returned status ${res.status}`);
        }
        
        const data = await res.json();
        console.log("✅ Transactions received:", data);
        setTransactions(data);
        setError(null);
      } catch (error) {
        console.error("❌ Error fetching transactions:", error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, []);

  if (loading) {
    return (
      <div className="page-container">
        <div className="transactions-container">
          <div className="wallets-container">
            <h2>Loading transactions...</h2>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="page-container">
        <div className="transactions-container">
          <div className="wallets-container">
            <h1>Transaction History</h1>
            <p style={{ color: "red" }}>❌ Error: {error}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="transactions-container">
        <div className="wallets-container">
          <h1>Transaction History</h1>

          {transactions.length === 0 ? (
            <p>No transactions found.</p>
          ) : (
            <div className="transactions-list">
              {transactions.map((tx) => (
                <TransactionCard key={tx._id} transaction={tx} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TransactionsHistoryPage;