import React from "react";
import "./gameLoading.css";

const GameLoading = () => {
  return (
    <div className="page-container">
      <div className="game-loading-container">
        <h2>Loading game</h2>
        <div className="spinner" aria-hidden="true" />
      </div>
    </div>
  );
};

export default GameLoading;
