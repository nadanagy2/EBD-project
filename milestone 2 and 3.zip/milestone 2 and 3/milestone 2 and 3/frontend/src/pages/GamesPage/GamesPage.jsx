import React from "react";
import GameCard from "../../components/GameCard/GameCard";
import "./GamesPage.css";

const GAMES = [
  { id: "g1", title: "Treasure Swipe", reward: 10, description: "Quick reflexes win 10 EGP." },
  { id: "g2", title: "Coin Match", reward: 15, description: "Find pairs to win 15 EGP." },
  { id: "g3", title: "Saving Sprint", reward: 20, description: "A small challenge for 20 EGP." },
  { id: "g4", title: "Piggy Pop", reward: 25, description: "Pop the piggy to collect 25 EGP." },
];

export default function GamesPage() {
  return (
    <div className="page-container games-page">
      <div className="wallets-container">
        <h1>Games</h1>
        <p className="muted">Pick a game and try to win the reward shown on the card.</p>

        <div className="games-grid">
          {GAMES.map((g) => (
            <GameCard key={g.id} {...g} />
          ))}
        </div>
      </div>
    </div>
  );
}
