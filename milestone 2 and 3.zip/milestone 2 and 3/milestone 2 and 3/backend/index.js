import "dotenv/config";
import express from "express";
import mongoose from "mongoose";
import cookieParser from "cookie-parser";
import cors from "cors";

/* =======================
   ROUTES
======================= */
import userRoutes from "./routers/user.routers.js";
import walletRoutes from "./routers/wallet.routers.js";
import missionRoutes from "./routers/mission.routers.js";
import voucherRoutes from "./routers/voucher.routers.js";
import transactionRoutes from "./routers/transaction.routers.js";

/* =======================
   MIDDLEWARE
======================= */
import errorHandler from "./Middleware/errorHandler.js";

const app = express();

/* =======================
   GLOBAL MIDDLEWARE
======================= */
app.use(express.json());
app.use(cookieParser());

// Updated CORS to be more specific for credentials (cookies) support
app.use(
  cors({
    origin: "http://localhost:5173", // Explicitly allow your Vite frontend
    credentials: true,
  })
);

/* =======================
   API ROUTES
======================= */
// Changed from "/api/users" to "/api/auth" to match your frontend api.js calls
app.use("/api/auth", userRoutes); 
app.use("/api/wallets", walletRoutes);
app.use("/api/missions", missionRoutes);
app.use("/api/vouchers", voucherRoutes);
app.use("/api/transactions", transactionRoutes);

// Root route to verify server is alive
app.get("/", (req, res) => {
  res.send("✅ API is running and healthy!");
});

/* =======================
   ERROR HANDLER (LAST)
======================= */
app.use(errorHandler);

/* =======================
   DATABASE + SERVER
======================= */
const PORT = 3000;

mongoose
  .connect(
    "mongodb+srv://habibaaahmed904_db_user:crbChsL9gtYloYKV@ebdcluster.onyxcwp.mongodb.net/EBDcluster?appName=EBDcluster"
  )
  .then(() => {
    console.log("✅ Connected to MongoDB");

    app.listen(PORT, () => {
      console.log(`🚀 Server running on http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error("❌ MongoDB connection error:", err.message);
  });