import { Router } from "express";
import * as missionController from "../controllers/mission.controller.js";
import { verifyToken } from "../Middleware/auth.js";

const router = Router();

// Child can view only their own missions
router.get("/", verifyToken, missionController.getMissions);

export default router;
