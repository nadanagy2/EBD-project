import { Router } from "express";
import * as voucherController from "../controllers/voucher.controller.js";
import { verifyToken } from "../Middleware/auth.js";
import Voucher from "../models/Voucher.js";

const router = Router();

// Child can view all vouchers
router.get("/", verifyToken, voucherController.getVouchers);

// DEV ONLY: Clear all vouchers (remove this in production)
router.delete("/dev/clear-all", async (req, res) => {
  try {
    const result = await Voucher.deleteMany({});
    res.json({ message: "All vouchers deleted", deletedCount: result.deletedCount });
  } catch (err) {
    res.status(500).json({ error: "Failed to delete vouchers" });
  }
});

// Optional: child can "buy" voucher
// router.post("/buy/:id", verifyToken, voucherController.buyVoucher);

export default router;
