import { Router } from "express";
import * as transactionController from "../controllers/transaction.controller.js";
import { verifyToken } from "../Middleware/auth.js";

const router = Router();

// Child can view only their own transactions
router.get("/", verifyToken, transactionController.getTransactions);

export default router;
