import { Router } from "express";
import * as walletController from "../controllers/wallet.controller.js";
import { verifyToken } from "../Middleware/auth.js";

const router = Router();

// Child can only view their own wallet
router.get("/", verifyToken, walletController.getWallets);

export default router;

